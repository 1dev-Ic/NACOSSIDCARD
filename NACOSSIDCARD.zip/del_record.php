<?php
include('connection.php');
?>

<body>
<?php
if (!isset($_GET['do']) || $_GET['do'] != 1) {
switch ($_GET['type']) {
case 'genlistedit':
$id=  $_GET['id'];
$query = "DELETE  FROM studentsinfo WHERE matNum = '$id'";

$result = mysqli_query($conn, $query) or die(mysqli_error($conn));					
?>
<script type="text/javascript">
alert("Successfully Deleted!");
window.location = "list.php";
</script>				
				
<?php
//break;
}
}
?>

</body>