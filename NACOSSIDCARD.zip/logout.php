<?php
if (session_start()){
session_destroy();
        unset($_SESSION['usrname']);
            header("location: login.php");
} else{
    header("location: login.php");
}
?>