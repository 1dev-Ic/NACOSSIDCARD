<?php
include ('connection.php');
require ('FPDF/fpdf.php');
include ('phpqrcode/lib/full/qrlib.php');
include ('phpqrcode/examples/config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $Admissionyear = $_POST["Ayear"]; 
    // Calling details from db
     $query = "SELECT * FROM studentsinfo WHERE Ayear = '$Admissionyear' ";
        $results = mysqli_query($conn, $query) or die (mysqli_error($conn));
        if (mysqli_num_rows($results) <= 0) {
            echo '<script type="text/javascript">';
            echo 'alert("Sorry, No redord found for the ID Number Provided!");';
            echo 'window.location = "print.php";';
            echo '</script>';
            }
            while ($row = mysqli_fetch_assoc($results)) {                    
                $matNum =  $row['matNum'];
                $Sname= $row['Sname'];
                $Oname =  $row['Fname']." ".$row['Mname'];
                $gender = $row['Gender'];
                $position =  $row['position'];
                $Ayear =  $row['Ayear'];
                $passportpath = $row['passportpath'];
                 // validation for expiration Date
                 $Expdate = $Ayear + 6;
                 //how to save PNG codes to server  
                   $tempDir = EXAMPLE_TMP_SERVERPATH;   
                   $codeContents = "Name: " . $Oname . " ". $Sname. "\n" . "ID No.: " . $matNum . "\n". "POST: ". $position . "\n" . "Year of Admission: " . $Ayear;
                   // we need to generate filename somehow, 
                   // with md5 or with database ID used to obtains $codeContents...
                   $fileName = '005_file_'.md5($codeContents).'.png';
                   $pngAbsoluteFilePath = $tempDir.$fileName;
                   $urlRelativeFilePath = EXAMPLE_TMP_URLRELPATH.$fileName;
                   // generating qr code
                   if (!file_exists($pngAbsoluteFilePath)) {
                       QRcode::png($codeContents, $pngAbsoluteFilePath);   
                   }
                   
                   // Instanciation of inherited class
                   $pdf = new FPDF('P','mm',array(55.118,85.852));
                   $pdf->AliasNbPages();
                   $pdf->AddPage('P');
                   $pdf->Image('images/idcardbg.jpg',0,0,55.118);   // BG
                   //passport
                   $pdf->Image($passportpath,14,23,27,35);
                   //qrcode
                   $pdf->Image($pngAbsoluteFilePath,35,66.5,18);
                   // Arial bold              
                   // TXT
                   $pdf->SetFont('Arial','B',18);
                   $pdf->Text(2, 63.5, $Sname);
                   $pdf->SetFont('Arial','B',12);
                   $pdf->Text(2, 67, $Oname);
                   $pdf->SetTextColor(0, 51, 0);
                   $pdf->SetFont('Arial','B',12);
                   $pdf->Text(2, 71.5, $matNum );
                   $pdf->SetFont('Arial','B',14);
                   $pdf->SetTextColor(128, 0, 0);
                   $pdf->Text(2, 78, $position);
                   // New bage for back of the Id
                   $pdf->AddPage('P');
                   $pdf->Image('images/idcardbg_back.jpg',0,0,55.118);
                   $pdf->Image($pngAbsoluteFilePath,15.5,16,23);
                   $pdf->SetTextColor(0, 0, 0);
                   $pdf->SetFont('Arial','B',6);
                   $pdf->Text(15.5, 41, "D.O.I: ". $Ayear);
                   $pdf->Text(28, 41, "EXP: ". $Expdate);   // BG
                   $pdf->Output($matNum.".pdf",'I');
                                }
                            }
 
             //funcution for testing usr inputs
             function test_input($data) {
             $data = trim($data);
             $data = stripslashes($data);
             $data = htmlspecialchars($data);
             $data = ucwords($data);
             return $data;
           }
  ?>
