<?php

    // connection to db
include('connection.php');

  // define variables and set to empty values
$matNum=$Sname = $Fname = $Mname = $Gender = $bGroup =$Faculty = $dept = $Ayear = $passportpath= "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $Sname = strtoupper(test_input($_POST["Sname"]));
  $Fname = test_input($_POST["Fname"]);
  $Mname = test_input($_POST["Mname"]);
  $Gender = test_input($_POST["gender"]);
  $position = test_input($_POST["position"]);
  $matNum = test_input($_POST["matNum"]);
  $Ayear = test_input($_POST["Ayear"]);
  $passportpath1 = $_FILES['file']['name'];
  $passportpath = preg_replace('/\s+/', '', $passportpath1);
  $target_dir = "passports/";
  $target_file = $target_dir . basename($passportpath);
  $uploadOk = 1;

  // Select image file type
  $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));


        // Check file size
        if ($passportpath > 500000) {
            echo '<script type="text/javascript">';
            echo 'alert("Image size is too big!");';
            echo 'window.location = "index.php";';
            echo '</script>';
            $uploadOk = 0;
        }  
        // Allow certain file formats
        if($imageFileType != "jpg") {
            echo '<script type="text/javascript">';
            echo 'alert("Sorr only JPG files are allowed!");';
            echo 'window.location = "index.php";';
            echo '</script>';
            $uploadOk = 0;
        }
        
        // Check if file already exists
        $sql = "SELECT SN FROM studentsinfo WHERE matNum='$matNum' ";
        $results = mysqli_query($conn, $sql);

        if (mysqli_num_rows($results) > 0) {
            $uploadOk = 0;
            echo '<script type="text/javascript">';
            echo 'alert("Sorry, You have already applied for ID Card!");';
            echo 'window.location = "index.php";';
            echo '</script>';
            }


        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo " ";
        // if everything is ok, try to upload file
        } else {
                // Insert record
                $query = "INSERT INTO studentsinfo (matNum, Sname, Fname, Mname, Gender, position, Ayear, passportpath) VALUES('$matNum','$Sname','$Fname','$Mname','$Gender','$position',$Ayear,'$target_file')";
                mysqli_query($conn,$query) or die(mysqli_error($conn));
                if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
                echo '<script type="text/javascript">';
                echo 'alert("You have Successfully Applied for your ID Card It will be issued to you through your H.O.D when its ready");';
                echo 'window.location = "index.php";';
                echo '</script>';
                } else {
                        echo '<script type="text/javascript">';
                        echo 'alert("Sorry, there was an error submitting your application.");';
                        echo 'window.location = "index.php";';
                        echo '</script>';
                        }
                    }

}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  $data = ucwords($data);
  return $data;
}

    // close connection
        mysqli_close($conn);
?>