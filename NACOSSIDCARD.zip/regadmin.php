<?php
include ('connection.php');
$username="AdsuIDcard";
$password=sha1("usdamubi2000");

$query = "INSERT INTO admins ( usrname, psw) VALUES('$username','$password')";
mysqli_query($conn,$query) or die(mysqli_error($conn));
?>