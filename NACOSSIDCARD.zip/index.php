<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title>ID Card Generating System</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
   
    <link href="css/main.css" rel="stylesheet" media="all">
</head>

<body>
    <div class="page-wrapper bg-lightgrey p-t-20 p-b-100 font-robo">
        <div class="wrapper wrapper--w968">
            <div class="card card-1">
                <div class="card-heading"><a href="login.php"><button class="btn btn--radius btn--green" type="button">Admin</button></a></div>
                <div class="card-body">
                    <h2 class="title">NIGERIA ASSOCIATION OF COMPUTER SCIENCE STUDENT [NACOSS] ADSU MUBI CHAPTER <br> ID Card Generating System</h2>
                    <form method="POST" action="Form_action.php" enctype="multipart/form-data">
                    <fieldset>
                    <legend><h4>Student data capture form:</h4></legend>
                    <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                <input class="input--style-1" type="text" placeholder="SURNAME *" name="Sname" required>
                            </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                <input class="input--style-1" type="text" placeholder="FIRST NAME *" name="Fname" required>
                            </div>
                            </div>
                            </div>
                        <div class="input-group">
                            <input class="input--style-1" type="text" placeholder="MIDDLE NAME" name="Mname">
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <input class="input--style-1" type="text" placeholder="POSITION *" name="position" required>
                                </div>
                            </div>                           
                            <div class="col-2">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                        <select name="gender" required>
                                            <option disabled="disabled" value="" selected="selected">GENDER *</option>
                                            <option>Male</option>
                                            <option>Female</option>
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                                               
                        <div class="row row-space">
                           
                            <div class="col-2">
                                <div class="input-group">
                                    <input class="input--style-1" type="text" placeholder="MATRICULATION NUMBER *" name="matNum" required>
                                </div>
                            </div>
                            <div class="col-2">
                            <div class="input-group">
                            <div class="input--style-1">
                            <select name="Ayear" required>
                                    <option disabled="disabled" value="" selected="selected">Year Of Admission *</option>
                                    <?php
                                    include('connection.php');
                                // select options from db
                                $sql = "SELECT * FROM ayears ";
                                $results = mysqli_query($conn, $sql);

                                if ($results->num_rows > 0){
                                    while($row = $results->fetch_assoc()){
                                    echo '<option value="'.$row['Ayear'].'">'.$row['Ayear'].'</option>';
                                }
                                }else{
                                    echo '<option value="">please wait!</option>';
                                    }
                                ?>
                                </select>
                                </div>
                                </div>
                            </div>
                        </div>
                            <div class="">
                                <label for="event describtion">PASSPORT *: <br> Image must be jpg and not above 500kb size with a resolution not below 500px * 500px.</label>
                                <input class="input--style-1" type="file" name="file" accept="image/*" required> <br>
                            </div>
                        <div class="p-t-20">
                            <button class="btn btn--radius btn--green" type="submit">Submit</button>
                        </div>
                    </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>
    <script src="ajaxDSLECT.js"></script>
    <!-- Main JS-->
    <script src="js/global.js"></script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->
