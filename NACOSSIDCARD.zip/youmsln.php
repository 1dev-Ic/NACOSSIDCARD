<?php
    session_start();

    if (!isset($_SESSION['usrname'])) {
        $_SESSION['msg'] = "you must loggin first";
        header('location: login.php');
    }
    
    if (isset($_GET['logout'])) {
        session_destroy();
        unset($_SESSION['usrname']);
            header("location: login.php");
    }
?>