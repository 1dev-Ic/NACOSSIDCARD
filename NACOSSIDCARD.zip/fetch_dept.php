<?php
include ('connection.php');

$sql = "SELECT * FROM departments WHERE faculty_id='".$_POST["faculty_id"]."' ORDER BY department";
$results = mysqli_query($conn, $sql);
$output = '<option value="">Select Department</option>';
while($row = $results->fetch_assoc()){
    $output .= '<option value="'.$row['department'].'">'.$row['department'].'</option>';
}

echo $output;
?>