-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2021 at 02:54 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nacossiddb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `ID` int(3) NOT NULL,
  `usrname` varchar(255) NOT NULL,
  `psw` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`ID`, `usrname`, `psw`) VALUES
(1, 'AdsuIDcard', '40fcb121e597536eec34e1202bbe91933278e137');

-- --------------------------------------------------------

--
-- Table structure for table `ayears`
--

CREATE TABLE `ayears` (
  `Ayear` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ayears`
--

INSERT INTO `ayears` (`Ayear`) VALUES
(2016),
(2017),
(2018),
(2019),
(2020),
(2021);

-- --------------------------------------------------------

--
-- Table structure for table `studentsinfo`
--

CREATE TABLE `studentsinfo` (
  `SN` int(11) NOT NULL,
  `matNum` varchar(10) NOT NULL,
  `Sname` varchar(255) NOT NULL,
  `Fname` varchar(255) NOT NULL,
  `Mname` varchar(255) DEFAULT NULL,
  `Gender` varchar(10) NOT NULL,
  `Ayear` int(4) NOT NULL,
  `position` varchar(50) NOT NULL,
  `passportpath` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentsinfo`
--

INSERT INTO `studentsinfo` (`SN`, `matNum`, `Sname`, `Fname`, `Mname`, `Gender`, `Ayear`, `position`, `passportpath`) VALUES
(2, '17U/360081', 'YUGUDA', 'Alhaji', '', 'Male', 2017, 'Software Dir.', 'passports/IMG_20210414_180615_448.JPG'),
(3, '17U/360002', 'LUKA', 'Gideon', '', 'Male', 2017, 'Welfare Dir.', 'passports/IMG_2356[1].JPG'),
(4, '16U/360363', 'REUBEN', 'Fyafa', '', 'Female', 2016, 'Treasurer', 'passports/IMG-20210414-WA0002.jpg'),
(5, '16U/360074', 'MATUKURE', 'Santomi', 'Ibrahim', 'Male', 2016, 'Auditor', 'passports/IMG-20210331-WA0007[1].jpg'),
(6, '16u/360170', 'DRAMBI', 'Emmanuel', 'Sini', 'Male', 2016, 'Fin. Secretary', 'passports/IMG_20210415_123417_127~2[1].jpg'),
(7, '16u/360274', 'ABRAHAM', 'Patience', 'Amarachi', 'Female', 2016, 'Vice President', 'passports/IMG_20210415_132942[1].jpg'),
(8, '16U/360198', 'MANASSEH', 'Biyama', '', 'Male', 2016, 'P.R.O II', 'passports/IMG_20210415_134128[1].jpg'),
(9, '17U/360107', 'ISHAYA', 'Chahyaandida', '', 'Male', 2017, 'Secretary', 'passports/passportresent.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ayears`
--
ALTER TABLE `ayears`
  ADD PRIMARY KEY (`Ayear`);

--
-- Indexes for table `studentsinfo`
--
ALTER TABLE `studentsinfo`
  ADD PRIMARY KEY (`SN`),
  ADD UNIQUE KEY `SN` (`SN`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `studentsinfo`
--
ALTER TABLE `studentsinfo`
  MODIFY `SN` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
