<?php
session_start();

// Initiallizing variable

$username= "";
$errors= array();

// establishing connection

include_once('connection.php');

// loggin user

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username=mysqli_real_escape_string($conn, $_POST['usrname']);
    $password=sha1(mysqli_real_escape_string($conn, $_POST['psw']));

        if(empty($username)) {
            array_push($errors, "username is required");
                     }

            if(empty($password)) {
                 array_push($errors, "password is required");
                        }

        if(count($errors) == 0) {
            $password = $password;

            $query = "SELECT * FROM admins WHERE usrname='$username' AND psw='$password' ";
            $results = mysqli_query($conn, $query);

                if (mysqli_num_rows($results) == 1) {
                    $_SESSION['usrname'] = $username;
                    $_SESSION['success'] ="You are now logged in";
                        header('location:Adashboard.php');
                }else {
                    array_push($errors, "wrong username or password");
                    echo '<script type="text/javascript">';
                        echo 'alert("Invalid Username Or Password");';
                        echo 'window.location = "login.php";';
                        echo '</script>';
                }
        }
}

?>