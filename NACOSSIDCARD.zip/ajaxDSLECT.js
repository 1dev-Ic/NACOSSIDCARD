$(document).ready(function(){
    $('#faculty').change(function(){
        var facultyID = $(this).val();
        $.ajax({
            url:"fetch_dept.php",
            type:"POST",          
            data: {faculty_id:facultyID},
            dataType:"text",
            success:function(data)
            {
                $('#department').html(data);
            },
        });
        });
    
    });