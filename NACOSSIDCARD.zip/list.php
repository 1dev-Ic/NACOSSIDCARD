<?php
    include('youmsln.php');
?>
<!doctype html>
<html lang="en">
  <head>
  	<title>Admin Dashboard</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<div class="p-4 pt-5">
		  		<a href="#" class="img logo rounded-circle mb-5" style="background-image: url(images/logo.jpg);"></a>
	        <ul class="list-unstyled components mb-5">
	          <li class="active">
	            <a href="Adashboard.php" >Home</a> 
	          </li>
	          <li>
	              <a href="print.php">Print</a>
	          </li>
	          <li>
              <a href="list.php" >Lists</a>
	          </li>
	         

	        <div class="footer">
	        	<p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Developed by Chahyaandida Ishaya, Department of Computer Science, Adamawa State University Mubi. <i class="icon-heart" aria-hidden="true"></i> Features <a href="https://colorlib.com" target="_blank">ThirdHouseDeveloper</a>
						  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
	        </div>

	      </div>
    	</nav>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5">

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <div class="container-fluid">

            <button type="button" id="sidebarCollapse" class="btn btn-primary">
              <i class="fa fa-bars"></i>
              <span class="sr-only">Toggle Menu</span>
            </button>
            <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa fa-bars"></i>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <h3>ID Card Generating System -Admin Dashboard</h3>
              <ul class="nav navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="Adashboard.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
                
              </ul>
            </div>
          </div>
        </nav>

        <h2 class="mb-4">List of Students</h2>
        <p>Select Year in the cell provided below to generate the lists of students ID for the given Year. Use the Delete Button to delete record per student. <br> <b> Note*:</b> deleted records can not be retrieved! </p>
        <form action="genlist.php" method="post">
                    <div class="form-inline">
                    <div  class="Form-control input-group" >
                        <?php include ('connection.php') ?>
                                <select name="Ayear" required>
                                    <option disabled="disabled" value="" selected="selected">Year Of Admission</option>
                                    <?php
                                // select options from db
                                $sql = "SELECT * FROM ayears ";
                                $results = mysqli_query($conn, $sql);

                                if ($results->num_rows > 0){
                                    while($row = $results->fetch_assoc()){
                                    echo '<option value="'.$row['Ayear'].'">'.$row['Ayear'].'</option>';
                                }
                                }else{
                                    echo '<option value="">please wait!</option>';
                                    }
                                ?>
                                </select>
                        <div class="btn">
                            <button class="btn-secondary" type="submit">Fetch Lists</button>
                        </div>
                    </div>
        </form>
      </div>
		</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>