<?php
include ('connection.php');
?>

 <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>MATRICULATION NUMBER</th> 
                                        <th>NAME</th>
                                        <th>GENDER</th>
                                        <th>POSITION</th>
                                        <th>YEAR OF ADMISSION</th>
                                    </tr>
                                </thead>
                                <tbody>

             <?php 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $Ayear = $_POST["Ayear"]; 
    
                 $query = "SELECT * FROM studentsinfo WHERE Ayear = '$Ayear'";
                    $results = mysqli_query($conn, $query) or die (mysqli_error($conn));
                
                
                        while ($row = mysqli_fetch_assoc($results)) {
                                            
                            echo '<tr>';
                            echo '<td>'. $row['matNum'].'</td>';
                            echo '<td>'. $row['Fname']." ".$row['Mname']." ".$row['Sname'].'</td>';
                            echo '<td>'. $row['Gender'].'</td>';
                            echo '<td>'. $row['position'].'</td>';
                            echo '<td>'. $row['Ayear'].'</td>';
                           
                            echo '<td>';
                            echo ' <a  type="button" class="btn btn-danger fa fa-trash" href="del_record.php?type=genlistedit&delete & id=' . $row['matNum'] . '">del</a> </td>';
                            echo '</tr> ';
                }

            }

            ?> 
                                    
                                </tbody>
                            </table>
                        </div>
